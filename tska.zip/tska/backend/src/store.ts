import { Person } from "./types";

export const people: Person[] = [];
